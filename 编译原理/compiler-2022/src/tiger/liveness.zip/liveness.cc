#include "tiger/liveness/liveness.h"

extern frame::RegManager *reg_manager;

namespace live {

bool MoveList::Contain(INodePtr src, INodePtr dst) {
  return std::any_of(move_list_.cbegin(), move_list_.cend(),
                     [src, dst](std::pair<INodePtr, INodePtr> move) {
                       return move.first == src && move.second == dst;
                     });
}

void MoveList::Delete(INodePtr src, INodePtr dst) {
  assert(src && dst);
  auto move_it = move_list_.begin();
  for (; move_it != move_list_.end(); move_it++) {
    if (move_it->first == src && move_it->second == dst) {
      break;
    }
  }
  move_list_.erase(move_it);
}

MoveList *MoveList::Union(MoveList *list) {
  auto *res = new MoveList();
  for (auto move : move_list_) {
    res->move_list_.push_back(move);
  }
  for (auto move : list->GetList()) {
    if (!res->Contain(move.first, move.second))
      res->move_list_.push_back(move);
  }
  return res;
}

MoveList *MoveList::Intersect(MoveList *list) {
  auto *res = new MoveList();
  for (auto move : list->GetList()) {
    if (Contain(move.first, move.second))
      res->move_list_.push_back(move);
  }
  return res;
}

void LiveGraphFactory::LiveMap() {
  /* TODO: Put your lab6 code here */
  for (auto &fnode : flowgraph_->Nodes()->GetList()) {
    in_.get()->Enter(fnode, new temp::TempList());
    out_.get()->Enter(fnode, new temp::TempList());
  }
  bool loop = true;
  while (loop) {
    // reset loop
    /*
     * in[s] = use[s] ∪ (out[s] – def[s])
     * out[s] = ∪(n∈succ[s]) in[n]
     *
     */
    loop = 0;
    for (auto node_iter = flowgraph_->Nodes()->GetList().rbegin();
         node_iter != flowgraph_->Nodes()->GetList().rend(); node_iter++) {
      // compute out
      temp::TempList *out_list = new temp::TempList();
      for (auto &succ_node : (*node_iter)->Succ()->GetList()) {
        out_list->Union(in_.get()->Look(succ_node));
      }
      // compute in
      // add curNode use
      temp::TempList *in_list = (*node_iter)->NodeInfo()->Use();
      // add curNode out-def
      temp::TempList *out_without_def = new temp::TempList();
      for (auto def : (*node_iter)->NodeInfo()->Def()->GetList()) {
        if (!out_list->Contain(def)) {
          out_without_def->Append(def);
        }
      }
      in_list = in_list->Union(out_without_def);

      // judge loop end
      if (!in_.get()->Look(*node_iter)->IsSame(in_list) ||
          !out_.get()->Look(*node_iter)->IsSame(out_list)) {
        out_.get()->Enter((*node_iter), out_list);
        in_.get()->Enter((*node_iter), in_list);
        loop = true;
      } else{
        loop = false;
      }
    }
  }
}

void LiveGraphFactory::InterfGraph() {
  /* TODO: Put your lab6 code here */
  auto &interf_graph = live_graph_.interf_graph;
  auto &moves = live_graph_.moves;

  interf_graph = new IGraph();
  moves = new MoveList();

  const auto &reg_list = reg_manager->Registers()->GetList(); // ignore %rsp

  for (auto reg : reg_list) { // pre color real registers
    temp_node_map_->Enter(reg, interf_graph->NewNode(reg));
  }
  // add edge for each real regsiter
  for (auto it = reg_list.begin(); it != reg_list.end(); it++) {
    for (auto it_2 = std::next(it); it_2 != reg_list.end(); it_2++) {
      interf_graph->AddEdge(temp_node_map_->Look(*it),
                            temp_node_map_->Look(*it_2));
      interf_graph->AddEdge(temp_node_map_->Look(*it_2),
                            temp_node_map_->Look(*it));
    }
  }
  // Add all registers in the control flow to the collision diagram
  for (auto &fnode : flowgraph_->Nodes()->GetList()) {
    auto uses_and_defs =
        fnode->NodeInfo()->Use()->Union(fnode->NodeInfo()->Def());
    for (auto reg : uses_and_defs->GetList()) {
      if (reg == reg_manager->StackPointer() || temp_node_map_->Look(reg)) {
        continue;
      }
      INodePtr inode = interf_graph->NewNode(reg);
      temp_node_map_->Enter(reg, inode);
    }
  }

  for (auto fnode : flowgraph_->Nodes()->GetList()) {
    auto instr = fnode->NodeInfo();
    auto out_list = out_->Look(fnode);
    // handle moveInstr specially
    if (typeid(*instr) == typeid(assem::MoveInstr)) {
      auto def = instr->Def()->GetList().front(); // dst temp
      auto use = instr->Use()->GetList().front(); // src temp
      auto def_node = temp_node_map_->Look(def);
      auto use_node = temp_node_map_->Look(use);
      
      // add interf edge
      auto out_sub_use_reg_list = out_list->Diff(instr->Use());
      for(auto reg : out_sub_use_reg_list->GetList()){
          if(reg == reg_manager->StackPointer()){
            continue;
          }
          auto out_node = temp_node_map_->Look(reg);
          interf_graph->AddEdge(def_node, out_node);
          interf_graph->AddEdge(out_node, def_node);
      }

      // save move insr
      if (!live_graph_.moves->Contain(temp_node_map_->Look(use),
                                      temp_node_map_->Look(def))) {
        live_graph_.moves->Append(use_node, def_node);
      }
    } else{
      // handle other instr
      auto def_reg_list = instr->Def()->GetList();
      auto out_reg_list = out_list->GetList();
      for(auto def : def_reg_list){
        if(def == reg_manager->StackPointer()){
          continue;
        }
        auto def_node = temp_node_map_->Look(def);
        for(auto out : out_reg_list){
          if(out == reg_manager->StackPointer()){
            continue;
          }
          auto out_node = temp_node_map_->Look(out);
          interf_graph->AddEdge(out_node, def_node);
          interf_graph->AddEdge(def_node, out_node);
        }
      }
    }
  }
}

void LiveGraphFactory::Liveness() {
  LiveMap();
  InterfGraph();
}

} // namespace live
