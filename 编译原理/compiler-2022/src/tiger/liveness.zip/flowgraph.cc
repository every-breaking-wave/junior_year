#include "tiger/liveness/flowgraph.h"

namespace fg {

void FlowGraphFactory::AssemFlowGraph() {
  /* TODO: Put your lab6 code here */
  auto instr_list = instr_list_->GetList();
  tab::Table<assem::Instr, FNode> instr_to_node;
  FNodePtr prev = nullptr;
  for (auto instr : instr_list) {
    FNodePtr node = flowgraph_->NewNode(instr);
    instr_to_node.Enter(instr, node);
    if (prev) {
      flowgraph_->AddEdge(prev, node);
    }

    if (typeid(*instr) == typeid(assem::LabelInstr)) {
      label_map_->Enter(static_cast<assem::LabelInstr *>(instr)->label_, node);
    }

    if (typeid(*instr) == typeid(assem::OperInstr) &&
        static_cast<assem::OperInstr *>(instr)->assem_.find("jmp") == 0) {
      prev = nullptr; // no condition jump
    } else {
      prev = node;
    }
  }
  // Handle the jump list
  for (auto node : flowgraph_->Nodes()->GetList()) {
    auto instr = node->NodeInfo();
    if (typeid(*instr) == typeid(assem::OperInstr) &&
        static_cast<assem::OperInstr *>(instr)->jumps_) {
      auto labels = static_cast<assem::OperInstr *>(instr)->jumps_->labels_;
      for (auto label : *labels) {
        flowgraph_->AddEdge(instr_to_node.Look(instr),
                            label_map_.get()->Look(label));
      }
    }
  }
}

} // namespace fg

namespace assem {

temp::TempList *LabelInstr::Def() const {
  /* TODO: Put your lab6 code here */
  return new temp::TempList();
}

temp::TempList *MoveInstr::Def() const {
  /* TODO: Put your lab6 code here */
  return dst_ ? dst_ : new temp::TempList();
}

temp::TempList *OperInstr::Def() const {
  /* TODO: Put your lab6 code here */
  return dst_ ? dst_ : new temp::TempList();
}

temp::TempList *LabelInstr::Use() const {
  /* TODO: Put your lab6 code here */
  return new temp::TempList();
}

temp::TempList *MoveInstr::Use() const {
  /* TODO: Put your lab6 code here */
  return src_ ? src_ : new temp::TempList();
}

temp::TempList *OperInstr::Use() const {
  /* TODO: Put your lab6 code here */
  return src_ ? src_ : new temp::TempList();
}
} // namespace assem
