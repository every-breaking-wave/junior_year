#include "tiger/regalloc/regalloc.h"

#include "tiger/output/logger.h"

extern frame::RegManager *reg_manager;

namespace ra {
/* TODO: Put your lab6 code here */

void RegAllocator::RegAlloc() {
  col::Result color_result;

  while (true) {
    live::LiveGraph liveness = AnalyzeLiveness(instr_list_);
    col::Color color_util(liveness);
    // TODO: 新增节点
    color_util.Paint();
    auto color_result = color_util.GetResult();
    if (color_result.spills->GetList().empty()) {
      break;
    }
    // rewrite program
    RewriteProgram(frame_, instr_list_, color_result.spills);
  }

  // after rewrite, remove useless move instr
  result_.get()->il_ =
      RemoveUselessMoveInstr(instr_list_, *(color_result.coloring));
  result_.get()->coloring_ = color_result.coloring;
}

live::LiveGraph RegAllocator::AnalyzeLiveness(assem::InstrList *instr_list) {
  fg::FlowGraphFactory flow_graph_factory(instr_list);
  flow_graph_factory.AssemFlowGraph(); // generate flow graph

  live::LiveGraphFactory live_graph_factory(flow_graph_factory.GetFlowGraph());
  live_graph_factory.Liveness(); // generate live graph

  return live_graph_factory.GetLiveGraph();
}

std::pair<temp::TempList *, assem::InstrList *>
RegAllocator::RewriteProgram(frame::Frame *frame,
                             const assem::InstrList *instrList,
                             const live::INodeListPtr spilled_nodes) {
  assem::InstrList *prev_instr_list = new assem::InstrList();
  auto new_temp_list = new temp::TempList();
  for (const auto &instr : instrList->GetList()) {
    prev_instr_list->Append(instr);
  }

  // handle all spilled node
  for (auto spilled_node : spilled_nodes->GetList()) {
    // alloca it on stack
    frame->offset -= reg_manager->WordSize();
    assem::InstrList *update_instr_list = new assem::InstrList();
    for (const auto &instr : prev_instr_list->GetList()) {
      auto use_regs = instr->Use();
      auto def_regs = instr->Def();
      if (use_regs->Contain(spilled_node->NodeInfo())) {
        std::string new_assem = "movq (" + frame->GetLabel() + "_framesize-" +
                                std::to_string(std::abs(frame->offset)) +
                                ")(`s0), `d0";
        // dst : new temp reg, src : frame_ptr - offset
        auto new_temp = temp::TempFactory::NewTemp();
        auto new_instr = new assem::OperInstr(
            new_assem, new temp::TempList({new_temp}),
            new temp::TempList({reg_manager->StackPointer()}), nullptr);
        update_instr_list->Append(new_instr);
        // replace temp in use_reg with new temp
        temp::TempList *new_use_regs = new temp::TempList();
        for (auto t : use_regs->GetList()) {
          if (t == spilled_node->NodeInfo()) {
            new_use_regs->Append(new_temp);
          } else {
            new_use_regs->Append(t);
          }
        }
        use_regs = new_use_regs;
        // add new temp to temp_list
        new_temp_list->Append(new_temp);
      }

      update_instr_list->Append(instr);

      if (def_regs->Contain(spilled_node->NodeInfo())) {
        std::string new_assem =
            "movq `s0,(" + frame->GetLabel() + "_framesize-" +
            std::to_string(std::abs(frame->offset)) + ")(`d0)";
        auto new_temp = temp::TempFactory::NewTemp();
        auto new_instr = new assem::OperInstr(
            new_assem, new temp::TempList({reg_manager->StackPointer()}),
            new temp::TempList({new_temp}), nullptr);
        update_instr_list->Append(new_instr);
        // replace temp in use_reg with new temp
        temp::TempList *new_def_regs = new temp::TempList();
        for (auto t : def_regs->GetList()) {
          if (t == spilled_node->NodeInfo()) {
            new_def_regs->Append(new_temp);
          } else {
            new_def_regs->Append(t);
          }
        }
        def_regs = new_def_regs;
        // add new temp to temp_list
        new_temp_list->Append(new_temp);
      }
    }
    prev_instr_list = update_instr_list;
  }
  auto new_instr_list = new assem::InstrList(prev_instr_list->GetList());
  return std::make_pair(new_temp_list, new_instr_list);
}

assem::InstrList *
RegAllocator::RemoveUselessMoveInstr(assem::InstrList *instr_list,
                                     temp::Map &temp_to_color) {
  assem::InstrList *res = new assem::InstrList();
  for (const auto &instr : instr_list->GetList()) {
    if (typeid(*instr) == typeid(assem::MoveInstr)) {
      temp::Temp *src = *instr->Use()->GetList().begin();
      temp::Temp *dst = *instr->Def()->GetList().begin();
      if(*temp_to_color.Look(src) == *temp_to_color.Look(dst)){
        continue;
      }
      res->Append(instr);
    }
  }
  return res;
}

} // namespace ra