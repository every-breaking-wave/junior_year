#ifndef TIGER_COMPILER_COLOR_H
#define TIGER_COMPILER_COLOR_H

#include <map>
#include <set>
#include <stack>
#include <vector>

#include "tiger/codegen/assem.h"
#include "tiger/frame/temp.h"
#include "tiger/liveness/liveness.h"
#include "tiger/util/graph.h"

namespace col {
struct Result {
  Result() : coloring(nullptr), spills(nullptr) {}
  Result(temp::Map *coloring, live::INodeListPtr spills)
      : coloring(coloring), spills(spills) {}
  temp::Map *coloring;
  live::INodeListPtr spills;
};

class Color {
  /* TODO: Put your lab6 code here */
public:
  explicit Color(live::LiveGraph live_graph);
  Color() = default;
  ~Color() = default;
  void Paint();

  void Init();
  void BuildMoveList();
  void BuildGraph();

  // Color phase
  Result GetResult() const;
  void ClassifyNode();
  void Simplify();
  void Coalesce();
  void Freeze();
  void SelectSpill();
  void SelectColor();

  // Assitant functions
  bool IsPreColored(temp::Temp *t);
  bool IsSimplifyNode(live::INodePtr node);
  live::INodePtr GetAliasNode(live::INodePtr node);
  bool GeogreOrBriggs(live::INodePtr u, live::INodePtr v);
  live::INodeListPtr GetInterfList(live::INodePtr node);
  void CombineNodes(live::INodePtr u, live::INodePtr v);
  void AddEdge(live::INodePtr u, live::INodePtr v);
  bool IsMoveRelated(live::INodePtr node);
  void FreezeMoves(live::INodePtr node);
  void EnableMoves(live::INodeListPtr node_list);
  void FromFreezeToSimple(live::INodePtr node);
  void FromSpillToSimple(live::INodePtr node);


private:
  live::LiveGraph liveness;
  std::map<temp::Temp*, std::string> temp_to_color;
  Result result_;
  live::INodeListPtr spilledNodes;

  live::INodeListPtr coalesceNodes;
  live::INodeListPtr coloredNodes;
  live::INodeListPtr inStackNodes;
  live::INodeListPtr simplifyNodes;
  live::INodeListPtr freezeNodes;
  live::INodeListPtr spillNodes;

  // save temp state of graph
  std::map<live::INodePtr, int> node_to_degree;
  // std::map<live::INodePtr, bool> if_node_in_stack;
  std::map<live::INodePtr, live::INodeListPtr> node_to_interf_list;
  std::set<std::pair<live::INodePtr, live::INodePtr>> interf_edge_set;

  live::MoveList moveList;
  live::MoveList coalescedMoveList; // 已经合并的传送指令集合
  live::MoveList constrainedMoveList; // 源与目标操作数冲突的传送指令集合
  live::MoveList activeMoveList;
  live::MoveList preparedMoveList;
  live::MoveList frozenMoveList;

  std::map<live::INodePtr, live::INodePtr> node_to_alias_node;
  std::map<live::INodePtr, live::MoveList> node_to_movelist;
};
} // namespace col

#endif // TIGER_COMPILER_COLOR_H
