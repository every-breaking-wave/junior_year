#include "tiger/regalloc/color.h"

extern frame::RegManager *reg_manager;

#define MAX_COLOR_SIZE reg_manager->Registers()->GetList().size()
namespace col {
/* TODO: Put your lab6 code here */
Color::Color(live::LiveGraph live_graph) : liveness(live_graph) {
  for (auto reg : reg_manager->Registers()->GetList()) {
    temp_to_color.insert(std::make_pair(reg, *temp::Map::Name()->Look(reg)));
  }
 spilledNodes = new live::INodeList();
 coalesceNodes = new live::INodeList();
 coloredNodes = new live::INodeList();
 inStackNodes = new live::INodeList();
 simplifyNodes = new live::INodeList();
 freezeNodes = new live::INodeList();
 spillNodes = new live::INodeList();

}

void Color::Init() {
  BuildMoveList();
  BuildGraph();
  ClassifyNode();
}

void Color::Paint() {
  Init();
loop:
  if (!simplifyNodes->GetList().empty()) {
    Simplify();
    goto judge;
  }
  if (!moveList.GetList().empty()) {
    Coalesce();
    goto judge;
  }
  if (!freezeNodes->GetList().empty()) {
    Freeze();
    goto judge;
  }
  if (!spillNodes->GetList().empty()) {
    SelectSpill();
    goto judge;
  }

judge:
  if (!spillNodes->GetList().empty() || !moveList.GetList().empty() ||
      !freezeNodes->GetList().empty() || !spillNodes->GetList().empty()) {
    goto loop;
  }

  SelectColor();
  result_.coloring = temp::Map::Empty();
  for (const auto &it : temp_to_color) {
    result_.coloring->Enter(it.first, new std::string(it.second));
  }
  // handle spill node
  result_.spills = new live::INodeList();
  result_.spills->CatList(spilledNodes);
}

void Color::BuildMoveList() {
  for (const auto &move : liveness.moves->GetList()) {
    live::INodePtr src = move.first;
    live::INodePtr dst = move.second;
    node_to_movelist[src].Append(src, dst);
    node_to_movelist[dst].Append(dst, src);
  }
  this->moveList = *(liveness.moves);
}

void Color::BuildGraph() {
  for (auto interf_node : liveness.interf_graph->Nodes()->GetList()) {
    node_to_degree[interf_node] = 0;
  }
  for (auto interf_node : liveness.interf_graph->Nodes()->GetList()) {
    for (auto node : interf_node->Adj()->GetList()) {
      AddEdge(node, interf_node);
    }
  }
}

bool Color::IsPreColored(temp::Temp *t) {
  // for (auto reg : reg_manager->Registers()->GetList()) {
  //   if (t == reg) {
  //     return true;
  //   }
  // }
  return temp_to_color.find(t) != temp_to_color.end();
  
}

bool Color::IsSimplifyNode(live::INodePtr node) {
  return !IsPreColored(node->NodeInfo()) && !IsMoveRelated(node) &&
         node_to_degree[node] < MAX_COLOR_SIZE;
}

live::INodePtr Color::GetAliasNode(live::INodePtr node) {
  if (!coalesceNodes->Contain(node)) {
    return node; // not coalesce yet, return itself
  }
  return GetAliasNode(node_to_alias_node.find(node)->second);
}

bool Color::GeogreOrBriggs(live::INodePtr u, live::INodePtr v) {
  bool flag = true;
  // judge Geogre condition
  auto interf_list = GetInterfList(v);
  // return true if all its interf node are low degree node or has conflicts
  // with the other node
  for (auto interf_node : interf_list->GetList()) {
    if (!IsPreColored(interf_node->NodeInfo()) &&
        node_to_degree[interf_node] >= MAX_COLOR_SIZE &&
        interf_edge_set.find(std::make_pair(interf_node, u)) ==
            interf_edge_set.end()) {
      flag = false;
      break;
    }
  }
  // judge Briggs conditon
  auto coalesceNodeList = GetInterfList(u)->Union(GetInterfList(v));
  int new_degree = 0;
  for (auto node : coalesceNodes->GetList()) {
    if (IsPreColored(node->NodeInfo()) ||
        node_to_degree[node] >= MAX_COLOR_SIZE) {
      new_degree++;
    }
  }
  // return true if there would not be a high degree node after coalescing
  if (new_degree >= MAX_COLOR_SIZE || IsPreColored(u->NodeInfo())) {
    flag = false;
  }
  return flag;
}

live::INodeListPtr Color::GetInterfList(live::INodePtr node) {
  // interfList[n] - (selectStack ∪ coalescedNodes)
  return this->node_to_interf_list.find(node)->second->Diff(
      coalesceNodes->Union(inStackNodes));
}

void Color::CombineNodes(live::INodePtr u, live::INodePtr v) {
  // TODO:
  if (freezeNodes->Contain(v)) {
    freezeNodes->DeleteNode(v);
  } else {
    spillNodes->DeleteNode(v);
  }

  coalesceNodes->Append(v);

  // update alias represent node to u
  node_to_alias_node[v] = u;

  auto it1 = node_to_movelist.find(u);
  auto it2 = node_to_movelist.find(v);

  // update u's related move instr
  it1->second = *it2->second.Union(&(it1->second));

  // TODO: enable

  for (auto &interf_node : GetInterfList(v)->GetList()) {
    AddEdge(interf_node, u);
    node_to_degree[v]--;
  }

  // TODO:
}

void Color::AddEdge(live::INodePtr u, live::INodePtr v) {
  if (u == v) {
    return;
  }
  // add interf_edge
  interf_edge_set.insert(std::make_pair(u, v));
  interf_edge_set.insert(std::make_pair(v, u));
  // update degree and temp interf edge
  if (!IsPreColored(u->NodeInfo())) {
    node_to_degree[u]++;
    node_to_interf_list[u]->Append(v);
  }
  if (!IsPreColored(v->NodeInfo())) {
    node_to_degree[v]++;
    node_to_interf_list[v]->Append(u);
  }
}

bool Color::IsMoveRelated(live::INodePtr node) {
  auto it = node_to_movelist.find(node);
  if (it == node_to_movelist.end()) {
    return false;
  }
  auto move_list =
      (it->second).Intersect(preparedMoveList.Union(&activeMoveList));
  return !move_list->GetList().empty();
}

void Color::FreezeMoves(live::INodePtr node) {
  auto it = node_to_movelist.find(node);
  auto move_list =
      it == node_to_movelist.end()
          ? live::MoveList()
          : *(it->second).Intersect(preparedMoveList.Union(&activeMoveList));
  for (const auto &move : move_list.GetList()) {
    live::INodePtr n;
    if (GetAliasNode(move.second) == GetAliasNode(node)) {
      n = GetAliasNode(move.first);
    } else {
      n = GetAliasNode(move.second);
    }
    // freeze move
    activeMoveList.Delete(move.first, move.second);
    frozenMoveList.Append(move.first, move.second);
    // TODO:
    if (IsSimplifyNode(n)) {
      FromFreezeToSimple(n);
    }
  }
}

void Color::EnableMoves(live::INodeListPtr node_list) {
  for (const auto &node : node_list->GetList()) {
    auto it = node_to_movelist.find(node);
    if (it != node_to_movelist.end()) {
      for (const auto &move :
           (it->second).Intersect(activeMoveList.Union(&moveList))->GetList()) {
        if (activeMoveList.Contain(move.first, move.second)) {
          activeMoveList.Delete(move.first, move.second);
          moveList.Append(move.first, move.second);
        }
      }
    }
  }
}

void Color::FromFreezeToSimple(live::INodePtr node) {
  freezeNodes->DeleteNode(node);
  simplifyNodes->Append(node);
}

void Color::FromSpillToSimple(live::INodePtr node) {
  spillNodes->DeleteNode(node);
  simplifyNodes->Append(node);
}

void Color::ClassifyNode() {
  for (auto &node : liveness.interf_graph->Nodes()->GetList()) {
    if (IsPreColored(node->NodeInfo())) {
      continue;
    }
    // classify nodes
    if (node_to_degree[node] >= MAX_COLOR_SIZE) {
      spillNodes->Append(node);
    } else if (IsMoveRelated(node)) {
      freezeNodes->Append(node);
    } else {
      simplifyNodes->Append(node);
    }
  }
  printf("spill node size %d\n", spillNodes->GetList().size());
  printf("freeze node size %d\n", freezeNodes->GetList().size());
  printf("simplify node size %d\n", simplifyNodes->GetList().size());
}

Result Color::GetResult() const { return this->result_; }

void Color::Simplify() {
  const auto &node_list = liveness.interf_graph->Nodes()->GetList();
  int node_size = node_list.size();
  // push node to stack
  //   std::stack<live::INodePtr> node_ptr_stack;

  // find the minimum degree node
  live::INodePtr min_degree_node = node_list.front();
  for (auto &node : node_list) {
    if (inStackNodes->Contain(node)) {
      continue;
    }
    if (node_to_degree.find(node)->second <
        node_to_degree.find(min_degree_node)->second) {
      min_degree_node = node;
    }
    if (node_to_degree.find(min_degree_node)->second <
        MAX_COLOR_SIZE) { // find the approprate node
      break;
    }
  }

  inStackNodes->Append(min_degree_node);
  simplifyNodes->DeleteNode(min_degree_node);

  // update degree
  node_to_degree[min_degree_node] = 0;
  // change degree in the graph
  for (auto &interf_node : GetInterfList(min_degree_node)->GetList()) {
    if (IsPreColored(interf_node->NodeInfo())) {
      continue;
    }
    node_to_degree[interf_node]--;
    if (node_to_degree[interf_node] == MAX_COLOR_SIZE - 1) {
      // TODO: enable move
      spillNodes->Append(interf_node);
      if (IsMoveRelated(interf_node)) {
        freezeNodes->Append(interf_node);
      } else {
        simplifyNodes->Append(interf_node);
      }
    }
  }
}

void Color::Coalesce() {
  auto move = this->moveList.GetList().front();
  live::INodePtr u, v;
  if (IsPreColored(move.second->NodeInfo())) { // if des is precolored
    u = GetAliasNode(move.second);
    v = GetAliasNode(move.first);
  } else {
    u = GetAliasNode(move.first);
    v = GetAliasNode(move.second);
  }
  moveList.Delete(move.first, move.second);
  if (u == v) {
    coalescedMoveList.Append(move.first, move.second);
    if (IsSimplifyNode(u)) {
      FromFreezeToSimple(u);
    }
    // TODO: 传送无关
  } else if (interf_edge_set.find(std::make_pair(u, v)) !=
                 interf_edge_set.end() ||
             IsPreColored(v->NodeInfo())) { // useless move related
    if (IsSimplifyNode(u)) {
      FromFreezeToSimple(u);
    }
    if (IsSimplifyNode(v)) {
      FromFreezeToSimple(v);
    }
  } else if (GeogreOrBriggs(u, v)) {
    coalescedMoveList.Append(move.first, move.second); // do coalesce
    CombineNodes(u, v);
    if (IsSimplifyNode(u)) {
      FromFreezeToSimple(u);
    }
  } else {
    activeMoveList.Append(move.first, move.second);
  }
}

void Color::Freeze() {
  // find a node to freeze : low degree, move related
  auto move_related_list =
      liveness.interf_graph->Nodes()->Diff(inStackNodes)->Diff(coalesceNodes);
  for (auto node : move_related_list->GetList()) {
    if (node_to_degree[node] < MAX_COLOR_SIZE && IsMoveRelated(node)) {
      FreezeMoves(node);
      FromFreezeToSimple(node); // activate it
      return;
    }
  }
}

void Color::SelectSpill() {
  // find max degree node to spill
  int max = 0;
  live::INodePtr spill_node = nullptr;
  auto spill_node_list =
      liveness.interf_graph->Nodes()->Diff(inStackNodes)->Diff(coalesceNodes);
  for (auto &node : spill_node_list->GetList()) {
    // TODO: added temps
    if (node_to_degree[node] >= MAX_COLOR_SIZE) {
      if (node_to_degree[node] > max) {
        max = node_to_degree[node];
        spill_node = node;
      }
    }
  }
  FromSpillToSimple(spill_node);
  FreezeMoves(spill_node);
}

void Color::SelectColor() {
  while (!inStackNodes->GetList().empty()) {
    temp::TempList *precolored_registers = reg_manager->Registers();

    auto node = inStackNodes->GetList().back();
    inStackNodes->DeleteNode(node);

    std::set<std::string> colors;
    for (const auto &it : precolored_registers->GetList()) {
      colors.insert(*temp::Map::Name()->Look(it));
    }
    for (const auto &interf_node : node_to_interf_list[node]->GetList()) {
      auto alias_node = GetAliasNode(interf_node);
      if (IsPreColored(alias_node->NodeInfo()) ||
          coloredNodes->Contain(alias_node)) {
        std::string color = temp_to_color.find(alias_node->NodeInfo())->second;
        if (colors.find(color) != colors.end()) {
          colors.erase(color);
        }
      }
    }
    if (colors.size() > 0) {
      coloredNodes->Append(node);
      temp_to_color.insert(std::make_pair(
          node->NodeInfo(), *(colors.begin()))); // choose a available color
    } else { // no enough color, spill the node
      spilledNodes->Append(node);
    }
  }

  // all simplify nodes are colored, then color coalesced nodes
  for (const auto &coaleced_node : coalesceNodes->GetList()) {
    std::string color =
        temp_to_color.find(GetAliasNode(coaleced_node)->NodeInfo())->second;
    temp_to_color.insert(std::make_pair(coaleced_node->NodeInfo(), color));
  }
}

} // namespace col
