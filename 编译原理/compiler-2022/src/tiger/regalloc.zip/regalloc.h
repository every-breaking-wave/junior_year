#ifndef TIGER_REGALLOC_REGALLOC_H_
#define TIGER_REGALLOC_REGALLOC_H_

#include "tiger/codegen/assem.h"
#include "tiger/codegen/codegen.h"
#include "tiger/frame/frame.h"
#include "tiger/frame/temp.h"
#include "tiger/liveness/liveness.h"
#include "tiger/regalloc/color.h"
#include "tiger/util/graph.h"

namespace ra {

class Result {
public:
  temp::Map *coloring_;
  assem::InstrList *il_;

  Result() : coloring_(nullptr), il_(nullptr) {}
  Result(temp::Map *coloring, assem::InstrList *il)
      : coloring_(coloring), il_(il) {}
  Result(const Result &result) = delete;
  Result(Result &&result) = delete;
  Result &operator=(const Result &result) = delete;
  Result &operator=(Result &&result) = delete;
  ~Result()=default;
};

class RegAllocator {
  /* TODO: Put your lab6 code here */
public:
  RegAllocator(frame::Frame *frame, std::unique_ptr<cg::AssemInstr> assem_instr) :
  frame_(frame), instr_list_(assem_instr.get()->GetInstrList()){
    result_ = std::make_unique<ra::Result>();
  }
  RegAllocator()=default;

  void RegAlloc();
  std::unique_ptr<ra::Result> TransferResult(){
    return std::move(result_);
  }
  static live::LiveGraph AnalyzeLiveness(assem::InstrList *instr_list);
  static std::pair<temp::TempList*, assem::InstrList*> 
    RewriteProgram(frame::Frame *frame, const assem::InstrList *instr_list, const live::INodeListPtr spilled_nodes);
  static assem::InstrList *RemoveUselessMoveInstr(assem::InstrList *instr_list, temp::Map &temp_to_color);

private:
  frame::Frame *frame_;                  // current fun frame
  assem::InstrList *instr_list_;        // assem instr list
  std::unique_ptr<ra::Result> result_;  // store the relation between virtual reg and real reg
};

} // namespace ra

#endif