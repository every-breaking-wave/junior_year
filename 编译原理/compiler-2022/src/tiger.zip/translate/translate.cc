#include "tiger/translate/translate.h"

#include <tiger/absyn/absyn.h>

#include "tiger/env/env.h"
#include "tiger/errormsg/errormsg.h"
#include "tiger/frame/frame.h"
#include "tiger/frame/temp.h"
#include "tiger/frame/x64frame.h"

extern frame::Frags *frags;
extern frame::RegManager *reg_manager;

namespace tr {

Access *Access::AllocLocal(Level *level, bool escape) {
  Access *access = new Access(level, level->frame_->AllocLocal(escape));
  return access;
}

Level *NewLevel(Level *parent, temp::Label *fun_name,
                const std::list<bool> &escape_list) {
  std::list<bool> temp_list = escape_list;
  temp_list.push_front(true); // stactic link is alloc in frame
  frame::Frame *frame_ = new frame::X64Frame(fun_name, temp_list);
  return new Level(frame_, parent);
}

class Cx {
public:
  PatchList trues_;
  PatchList falses_;
  tree::Stm *stm_;

  Cx(PatchList trues, PatchList falses, tree::Stm *stm)
      : trues_(trues), falses_(falses), stm_(stm) {}
};

class Exp {
public:
  [[nodiscard]] virtual tree::Exp *UnEx() = 0;
  [[nodiscard]] virtual tree::Stm *UnNx() = 0;
  [[nodiscard]] virtual Cx UnCx(err::ErrorMsg *errormsg) = 0;
};

class ExpAndTy {
public:
  tr::Exp *exp_;
  type::Ty *ty_;

  ExpAndTy(tr::Exp *exp, type::Ty *ty) : exp_(exp), ty_(ty) {}
};

class ExExp : public Exp {
public:
  tree::Exp *exp_;

  explicit ExExp(tree::Exp *exp) : exp_(exp) {}

  [[nodiscard]] tree::Exp *UnEx() override {
    // tran ExExp to Exp
    return exp_;
  }
  [[nodiscard]] tree::Stm *UnNx() override {
    // tran ExExp to Stm
    return new tree::ExpStm(exp_);
  }
  [[nodiscard]] Cx UnCx(err::ErrorMsg *errormsg) override {
    // tran ExExp to Cx
    // add new labels for condition jump
    temp::Label *true_label = temp::LabelFactory::NewLabel();
    temp::Label *false_label = temp::LabelFactory::NewLabel();
    std::list<temp::Label **> true_label_list;
    std::list<temp::Label **> false_label_list;
    true_label_list.emplace_back(&true_label);
    false_label_list.emplace_back(&false_label);
    // tran exp to CjumpStm, using ConstExp(0) as right exp
    tree::CjumpStm *cjStm = new tree::CjumpStm(
        tree::NE_OP, exp_, new tree::ConstExp(0), true_label, false_label);
    return Cx(*(new PatchList(true_label_list)),
              *(new PatchList(false_label_list)), cjStm);
  }
};

class NxExp : public Exp {
public:
  tree::Stm *stm_;

  explicit NxExp(tree::Stm *stm) : stm_(stm) {}

  [[nodiscard]] tree::Exp *UnEx() override {
    return new tree::EseqExp(stm_, new tree::ConstExp(0));
  }
  [[nodiscard]] tree::Stm *UnNx() override { return stm_; }
  [[nodiscard]] Cx UnCx(err::ErrorMsg *errormsg) override {
    // Nx cannot be a Cx
    assert(false);
    printf("Nx cannot be a Cx\n");
  }
};

class CxExp : public Exp {
public:
  Cx cx_;

  CxExp(PatchList trues, PatchList falses, tree::Stm *stm)
      : cx_(trues, falses, stm) {}

  [[nodiscard]] tree::Exp *UnEx() override {
    temp::Temp *r =
        temp::TempFactory::NewTemp(); // a temp register to save condition value
    temp::Label *true_label = temp::LabelFactory::NewLabel();
    temp::Label *false_label = temp::LabelFactory::NewLabel();
    return
        // tran Cx to EseqExp
        new tree::EseqExp(
            new tree::MoveStm(new tree::TempExp(r),
                              new tree::ConstExp(1)), // pass 1 to temp r
            new tree::EseqExp(
                cx_.stm_, // run stm_
                new tree::EseqExp(
                    new tree::LabelStm(false_label), // mark false label
                    new tree::EseqExp(
                        new tree::MoveStm(
                            new tree::TempExp(r),
                            new tree::ConstExp(0)), // if false, mark r as 0
                        new tree::EseqExp(
                            new tree::LabelStm(true_label),
                            new tree::TempExp(
                                r)))))); // else, mark true label, skip the
                                         // process of marking r as 1 'cause
                                         // default value is bigger than 0
  }
  [[nodiscard]] tree::Stm *UnNx() override {
    // instead tran to Nx directly, fisrt tran to Ex, then tran Ex to Nx for it
    // is quite simple to multi-tran between Ex and Nx
    return new tree::ExpStm(UnEx());
  }
  [[nodiscard]] Cx UnCx(err::ErrorMsg *errormsg) override { return cx_; }
};

void ProgTr::Translate() {
  absyn_tree_->Translate(
      venv_.get(), tenv_.get(),
      new Level(new frame::X64Frame(temp::LabelFactory::NamedLabel("main"), {}),
                nullptr),
      temp::LabelFactory::NamedLabel("main"), errormsg_.get());
}

tree::Exp *StaticLink(tr::Level *current, tr::Level *target) {
  //  Derive the calculated expression from the current and target stack frame
  //  level
  // let exp point to Frame Register %rbp
  tree::Exp *staticlink = new tree::TempExp(reg_manager->FramePointer());
  while (current != target) { // find frame access from frame bottom
    if (!current) {
      return nullptr;
    }
    //  The staticlink should be the first argument to the stack frame
    staticlink = current->frame_->formals->GetList().front()->ToExp(staticlink);
    current = current->parent_;
  }
  return staticlink;
}

} // namespace tr

// translation process : from var/exp/dec/ty to tr::Exp and ty, then tran them
// to tr::ExpAndTy

namespace absyn {

tr::ExpAndTy *AbsynTree::Translate(env::VEnvPtr venv, env::TEnvPtr tenv,
                                   tr::Level *level, temp::Label *label,
                                   err::ErrorMsg *errormsg) const {
  root_->Translate(venv, tenv, level, label, errormsg);
}

tr::ExpAndTy *SimpleVar::Translate(env::VEnvPtr venv, env::TEnvPtr tenv,
                                   tr::Level *level, temp::Label *label,
                                   err::ErrorMsg *errormsg) const {
  tr::Exp *exp = nullptr;
  type::Ty *ty;

  env::VarEntry *var_entry = static_cast<env::VarEntry *>(venv->Look(sym_));

  // find static link fp
  ty = var_entry->ty_->ActualTy();
  exp = new tr::ExExp(var_entry->access_->access_->ToExp(
      tr::StaticLink(var_entry->access_->level_, level)));
  return new tr::ExpAndTy(exp, ty);
}

tr::ExpAndTy *FieldVar::Translate(env::VEnvPtr venv, env::TEnvPtr tenv,
                                  tr::Level *level, temp::Label *label,
                                  err::ErrorMsg *errormsg) const {
  // translate var
  tr::ExpAndTy *tr_var = var_->Translate(venv, tenv, level, label, errormsg);
  // cast ty to record_ty
  type::RecordTy *record_ty =
      static_cast<type::RecordTy *>(tr_var->ty_->ActualTy());

  int i = 0;
  const auto &field_list = (record_ty->fields_->GetList());
  for (auto field : field_list) {
    if (field->name_->Name() == sym_->Name()) {
      tree::MemExp *exp = tree::getMemExpByBaseAndIndex(
          tr_var->exp_->UnEx(), (i * frame::X64Frame::regManager.WordSize()));
      return new tr::ExpAndTy(new tr::ExExp(exp), tr_var->ty_->ActualTy());
    }
    i++;
  }
  return new tr::ExpAndTy(NULL, type::IntTy::Instance());
};

tr::ExpAndTy *SubscriptVar::Translate(env::VEnvPtr venv, env::TEnvPtr tenv,
                                      tr::Level *level, temp::Label *label,
                                      err::ErrorMsg *errormsg) const {}

tr::ExpAndTy *VarExp::Translate(env::VEnvPtr venv, env::TEnvPtr tenv,
                                tr::Level *level, temp::Label *label,
                                err::ErrorMsg *errormsg) const {
  return this->var_->Translate(venv, tenv, level, label, errormsg);
}

tr::ExpAndTy *NilExp::Translate(env::VEnvPtr venv, env::TEnvPtr tenv,
                                tr::Level *level, temp::Label *label,
                                err::ErrorMsg *errormsg) const {
  return new tr::ExpAndTy(new tr::ExExp(new tree::ConstExp(0)),
                          type::NilTy::Instance());
}

tr::ExpAndTy *IntExp::Translate(env::VEnvPtr venv, env::TEnvPtr tenv,
                                tr::Level *level, temp::Label *label,
                                err::ErrorMsg *errormsg) const {
  return new tr::ExpAndTy(new tr::ExExp(new tree::ConstExp(val_)),
                          type::IntTy::Instance());
}

tr::ExpAndTy *StringExp::Translate(env::VEnvPtr venv, env::TEnvPtr tenv,
                                   tr::Level *level, temp::Label *label,
                                   err::ErrorMsg *errormsg) const {
  temp::Label *string_label = temp::LabelFactory::NewLabel();
  frags->PushBack(new frame::StringFrag(string_label, str_));
  return new tr::ExpAndTy(new tr::ExExp(new tree::NameExp(string_label)),
                          type::StringTy::Instance());
}

tr::ExpAndTy *CallExp::Translate(env::VEnvPtr venv, env::TEnvPtr tenv,
                                 tr::Level *level, temp::Label *label,
                                 err::ErrorMsg *errormsg) const {}

tr::ExpAndTy *OpExp::Translate(env::VEnvPtr venv, env::TEnvPtr tenv,
                               tr::Level *level, temp::Label *label,
                               err::ErrorMsg *errormsg) const {
  tree::CjumpStm *stm = nullptr;
  tree::BinopExp *exp = nullptr;
  // translate left and right
  tr::ExpAndTy *tr_left = left_->Translate(venv, tenv, level, label, errormsg);
  tr::ExpAndTy *tr_right =
      right_->Translate(venv, tenv, level, label, errormsg);
  tr::Exp *left = tr_left->exp_;
  tr::Exp *right = tr_right->exp_;
  switch (oper_) {
    // + - * /
  case absyn::PLUS_OP:
    exp = new tree::BinopExp(tree::BinOp::PLUS_OP, left->UnEx(), right->UnEx());
    break;
  case absyn::MINUS_OP:
    exp =
        new tree::BinopExp(tree::BinOp::MINUS_OP, left->UnEx(), right->UnEx());
    break;
  case absyn::TIMES_OP:
    exp = new tree::BinopExp(tree::BinOp::MUL_OP, left->UnEx(), right->UnEx());
    break;
  case absyn::DIVIDE_OP:
    exp = new tree::BinopExp(tree::BinOp::DIV_OP, left->UnEx(), right->UnEx());
    break;
    // == != < <= > >=
  case absyn::EQ_OP:
    stm = new tree::CjumpStm(tree::RelOp::EQ_OP, left->UnEx(), right->UnEx(),
                             nullptr, nullptr);
    break;
  case absyn::NEQ_OP:
    stm = new tree::CjumpStm(tree::RelOp::NE_OP, left->UnEx(), right->UnEx(),
                             nullptr, nullptr);
    break;
  case absyn::LT_OP:
    stm = new tree::CjumpStm(tree::RelOp::LT_OP, left->UnEx(), right->UnEx(),
                             nullptr, nullptr);
    break;
  case absyn::LE_OP:
    stm = new tree::CjumpStm(tree::RelOp::LE_OP, left->UnEx(), right->UnEx(),
                             nullptr, nullptr);
    break;
  case absyn::GT_OP:
    stm = new tree::CjumpStm(tree::RelOp::GT_OP, left->UnEx(), right->UnEx(),
                             nullptr, nullptr);
    break;
  case absyn::GE_OP:
    stm = new tree::CjumpStm(tree::RelOp::GE_OP, left->UnEx(), right->UnEx(),
                             nullptr, nullptr);
    break;
  }
  tr::Exp *exp_ = nullptr;
  if (stm) {
    std::list<temp::Label **> true_label_list;
    std::list<temp::Label **> false_label_list;
    true_label_list.emplace_back(&(stm->true_label_));
    false_label_list.emplace_back(&(stm->false_label_));
    exp_ = new tr::CxExp(*(new tr::PatchList(true_label_list)),
                         *(new tr::PatchList(false_label_list)), stm);
  } else {
    exp_ = new tr::ExExp(exp);
  }
  return new tr::ExpAndTy(exp_, type::IntTy::Instance());
}

tr::ExpAndTy *RecordExp::Translate(env::VEnvPtr venv, env::TEnvPtr tenv,
                                   tr::Level *level, temp::Label *label,
                                   err::ErrorMsg *errormsg) const {
  tree::ExpList *explist = new tree::ExpList();
  for (const auto &field : this->fields_->GetList()) {
    auto tr_exp = field->exp_->Translate(venv, tenv, level, label, errormsg);
    explist->Append(tr_exp->exp_->UnEx());
  }
  int num = static_cast<int>(fields_->GetList().size());
  auto reg = temp::TempFactory::NewTemp();
  auto exp_list = new tree::ExpList();
  exp_list->Append(
      new tree::ConstExp(num * frame::X64Frame::regManager.WordSize()));
  tree::Stm *stm = new tree::MoveStm(
      new tree::TempExp(reg), frame::externalCall("alloc_record", exp_list));

  num = 0;
  auto expressions = explist->GetList();
  for (auto &expr : expressions) {
    auto dst = tree::getMemExpByBaseAndIndex(
        new tree::TempExp(reg), (num * frame::X64Frame::regManager.WordSize()));
    stm = (new tree::SeqStm(stm, new tree::MoveStm(dst, expr)));
    ++num;
  }

  tr::ExExp *exp =
      new tr::ExExp(new tree::EseqExp(stm, new tree::TempExp(reg)));
  return new tr::ExpAndTy(exp, tenv->Look(typ_)->ActualTy());
}

tr::ExpAndTy *SeqExp::Translate(env::VEnvPtr venv, env::TEnvPtr tenv,
                                tr::Level *level, temp::Label *label,
                                err::ErrorMsg *errormsg) const {
  const auto &exp_list = seq_->GetList();
  type::Ty *ty = type::IntTy::Instance();
  tr::Exp *left =
      new tr::ExExp(new tree::ConstExp(0)); // initialize left exp as null
  // translate absyn::exp to tr::exp one by one
  for (auto exp : exp_list) {
    tr::ExpAndTy *tr_exp = exp->Translate(venv, tenv, level, label, errormsg);
    tr::Exp *right = tr_exp->exp_;
    ty = tr_exp->ty_->ActualTy();
    left = new tr::ExExp(new tree::EseqExp(left->UnNx(), right ? right->UnEx() : new tree::ConstExp(0)));
  }
  return new tr::ExpAndTy(left, ty);
}

tr::ExpAndTy *AssignExp::Translate(env::VEnvPtr venv, env::TEnvPtr tenv,
                                   tr::Level *level, temp::Label *label,
                                   err::ErrorMsg *errormsg) const {
  tr::ExpAndTy *tr_var = var_->Translate(venv, tenv, level, label, errormsg);
  tr::ExpAndTy *tr_exp = exp_->Translate(venv, tenv, level, label, errormsg);
  // execute move instruction, exp->var
  tree::MoveStm *move_stm =
      new tree::MoveStm(tr_var->exp_->UnEx(), tr_exp->exp_->UnEx());
  return new tr::ExpAndTy(new tr::NxExp(move_stm), type::VoidTy::Instance());
}

tr::ExpAndTy *IfExp::Translate(env::VEnvPtr venv, env::TEnvPtr tenv,
                               tr::Level *level, temp::Label *label,
                               err::ErrorMsg *errormsg) const {
  auto tr_test = this->test_->Translate(venv, tenv, level, label, errormsg);
  auto tr_then = this->then_->Translate(venv, tenv, level, label, errormsg);
  tr::ExpAndTy *tr_else(nullptr); // tr_else may not exist
  if (this->elsee_) {
    tr_else = this->elsee_->Translate(venv, tenv, level, label, errormsg);
  }

  temp::Temp *ret = temp::TempFactory::NewTemp(); // register save return value

  temp::Label *true_label = temp::LabelFactory::NewLabel();  
  temp::Label *false_label = temp::LabelFactory::NewLabel(); 
  temp::Label *done_label = temp::LabelFactory::NewLabel();
  auto done_label_vector = new std::vector<temp::Label *>;
  done_label_vector->emplace_back(done_label); // setting done label list

  // generate a new Cx by test
  tr::Cx cx = tr_test->exp_->UnCx(errormsg);
  // do patch
  cx.falses_.DoPatch(false_label);
  cx.trues_.DoPatch(true_label);
  tr::Exp *exp;
  if (elsee_) {
    exp = new tr::ExExp(new tree::EseqExp(
        cx.stm_,
        new tree::EseqExp(
            // if test is true, pass then value to ret register
            new tree::LabelStm(true_label),
            new tree::EseqExp(
                new tree::MoveStm(new tree::TempExp(ret),
                                  tr_then->exp_->UnEx()),
                new tree::EseqExp(
                    // if test is true, jump to done label directly
                    new tree::JumpStm(new tree::NameExp(done_label),
                                      done_label_vector),
                    new tree::EseqExp(
                        // if test is false, pass else value to ret register
                        new tree::LabelStm(false_label),
                        new tree::EseqExp(
                            new tree::MoveStm(new tree::TempExp(ret),
                                              tr_else->exp_->UnEx()),
                            new tree::EseqExp(
                                new tree::JumpStm(new tree::NameExp(done_label),
                                                  done_label_vector),
                                // setting ret register as return valuee
                                new tree::EseqExp(
                                    new tree::LabelStm(done_label),
                                    new tree::TempExp(ret))))))))));
  } else {
    exp = new tr::NxExp(new tree::SeqStm(
        cx.stm_,
        new tree::SeqStm(new tree::LabelStm(true_label),
                         new tree::SeqStm(tr_then->exp_->UnNx(),
                                          // if test is false, skip then
                                          new tree::LabelStm(false_label)))));
  }
  return new tr::ExpAndTy(exp, tr_then->ty_->ActualTy());
}

tr::ExpAndTy *WhileExp::Translate(env::VEnvPtr venv, env::TEnvPtr tenv,
                                  tr::Level *level, temp::Label *label,
                                  err::ErrorMsg *errormsg) const {
  auto tr_test = this->test_->Translate(venv, tenv, level, label, errormsg);
  auto tr_body = this->body_->Translate(venv, tenv, level, label, errormsg);
  auto test_label = temp::LabelFactory::NewLabel();
  auto done_label = temp::LabelFactory::NewLabel();
  auto body_label = temp::LabelFactory::NewLabel();
  tr::Cx cx = tr_test->exp_->UnCx(errormsg);
  cx.trues_.DoPatch(body_label);  // if test true, goto body
  cx.falses_.DoPatch(done_label); // else go to done
  std::vector<temp::Label *> *test_vector_ptr = new std::vector<temp::Label *>;
  test_vector_ptr->emplace_back(test_label);
  // consider while_exp as no elsee_ if_exp, test label as done label
  tr::Exp *exp = new tr::NxExp(new tree::SeqStm(
      new tree::LabelStm(test_label),
      new tree::SeqStm(
          cx.stm_, new tree::SeqStm(
                       new tree::LabelStm(body_label),
                       new tree::SeqStm(
                           tr_body->exp_->UnNx(),
                           new tree::SeqStm(
                               new tree::JumpStm(new tree::NameExp(test_label),
                                                 test_vector_ptr),
                               new tree::LabelStm(done_label)))))));
  return new tr::ExpAndTy(exp, type::VoidTy::Instance());
}

tr::ExpAndTy *ForExp::Translate(env::VEnvPtr venv, env::TEnvPtr tenv,
                                tr::Level *level, temp::Label *label,
                                err::ErrorMsg *errormsg) const {
  venv->BeginScope();
  // translate lo and hi, body
  auto tr_lo = this->lo_->Translate(venv, tenv, level, label, errormsg);
  auto tr_hi = this->hi_->Translate(venv, tenv, level, label, errormsg);
  tr::Access *loop_access = tr::Access::AllocLocal(
      level, escape_); // loop var in for_loop, considered as i
  venv->Enter(this->var_,
              new env::VarEntry(loop_access, tr_lo->ty_->ActualTy()));
  // translate body in a new venv
  auto tr_body = this->hi_->Translate(venv, tenv, level, label, errormsg);
  venv->EndScope();
  // consider for loop as if_exp, test if i<hi, if true, goto body,i++ if false,
  // goto done
  temp::Label *body_label = temp::LabelFactory::NewLabel();
  temp::Label *test_label = temp::LabelFactory::NewLabel();
  temp::Label *done_label = temp::LabelFactory::NewLabel();

  // assign loop var to value of lo, if it is escape, it will be store in frame,
  // else in register
  tree::Exp *i = loop_access->access_->ToExp(
      new tree::TempExp(reg_manager->FramePointer()));
  tr::Exp *exp = new tr::NxExp(new tree::SeqStm(
      new tree::MoveStm(i, tr_lo->exp_->UnEx()),
      new tree::SeqStm(
          new tree::LabelStm(test_label),
          new tree::SeqStm(
              new tree::CjumpStm(tree::RelOp::LE_OP, i, tr_hi->exp_->UnEx(),
                                 body_label, done_label),
              new tree::SeqStm(
                  new tree::LabelStm(body_label),
                  new tree::SeqStm(
                      tr_body->exp_->UnNx(),
                      new tree::SeqStm(
                          new tree::MoveStm(
                              i, new tree::BinopExp(tree::BinOp::PLUS_OP, i,
                                                    new tree::ConstExp(1))),
                          new tree::SeqStm(
                              new tree::JumpStm(new tree::NameExp(test_label),
                                                new std::vector<temp::Label *>(
                                                    1, test_label)),
                              new tree::LabelStm(done_label)))))))));
  return new tr::ExpAndTy(exp, type::VoidTy::Instance());
}

tr::ExpAndTy *BreakExp::Translate(env::VEnvPtr venv, env::TEnvPtr tenv,
                                  tr::Level *level, temp::Label *label,
                                  err::ErrorMsg *errormsg) const {
  // jump to break target label
  auto jump_labels = new std::vector<temp::Label *>(1, label);
  return new tr::ExpAndTy(
      new tr::NxExp(new tree::JumpStm(new tree::NameExp(label), jump_labels)),
      type::VoidTy::Instance());
}

tr::ExpAndTy *LetExp::Translate(env::VEnvPtr venv, env::TEnvPtr tenv,
                                tr::Level *level, temp::Label *label,
                                err::ErrorMsg *errormsg) const {
  const auto &decs = this->decs_->GetList();
  std::list<tr::Exp *> tr_dec_list; // store translated decs
  // translate decs
  for (auto dec : decs) {
    tr_dec_list.emplace_back(
        dec->Translate(venv, tenv, level, label, errormsg));
  }
  tr::Exp *res = nullptr;
  if (tr_dec_list.size() > 0) {
    res = tr_dec_list.front();
    for (auto dec : tr_dec_list) {
      if (dec) { // translate dec to Ex, res to Nx
        res = new tr::ExExp(new tree::EseqExp(res->UnNx(), dec->UnEx()));
      } else {
        res = new tr::ExExp(
            new tree::EseqExp(res->UnNx(), new tree::ConstExp(0)));
      }
    }
  }

  // translate body
  tr::ExpAndTy *tr_body = body_->Translate(venv, tenv, level, label, errormsg);
  if (res) {
    tr::ExExp *let_exp =
        new tr::ExExp(new tree::EseqExp(res->UnNx(), tr_body->exp_->UnEx()));
    return new tr::ExpAndTy(let_exp, tr_body->ty_->ActualTy());
  } else { // means there is no dec
    return tr_body;
  }
}

tr::ExpAndTy *ArrayExp::Translate(env::VEnvPtr venv, env::TEnvPtr tenv,
                                  tr::Level *level, temp::Label *label,
                                  err::ErrorMsg *errormsg) const {
  type::Ty *ty = tenv->Look(typ_); // get array type
  tr::ExpAndTy *tr_size = size_->Translate(venv, tenv, level, label, errormsg);
  tr::ExpAndTy *tr_init = init_->Translate(venv, tenv, level, label, errormsg);
  // alloc array on heap by externel call
  tree::Exp *array_exp = frame::externalCall(
      "init_array",
      new tree::ExpList({tr_size->exp_->UnEx(), tr_init->exp_->UnEx()}));
  return new tr::ExpAndTy(new tr::ExExp(array_exp), ty->ActualTy());
}

tr::ExpAndTy *VoidExp::Translate(env::VEnvPtr venv, env::TEnvPtr tenv,
                                 tr::Level *level, temp::Label *label,
                                 err::ErrorMsg *errormsg) const {
  return new tr::ExpAndTy(nullptr, type::VoidTy::Instance());
}

tr::Exp *FunctionDec::Translate(env::VEnvPtr venv, env::TEnvPtr tenv,
                                tr::Level *level, temp::Label *label,
                                err::ErrorMsg *errormsg) const {
  const auto &func_dec_list = this->functions_->GetList();
  // add all fun_dec entry to venv one by one
  for (auto func_dec : func_dec_list) {
    // build escape table
    std::list<bool> esacpes;
    for (auto field : func_dec->params_->GetList()) {
      esacpes.emplace_back(field->escape_);
    }
    // add a level for this func
    temp::Label *new_label =
        temp::LabelFactory::NamedLabel(func_dec->name_->Name());
    tr::Level *new_level = tr::NewLevel(level, new_label, esacpes);
    if (func_dec->result_) { // fun has a return value
      type::Ty *result_ty = tenv->Look(func_dec->result_);
      venv->Enter(
          func_dec->name_,
          new env::FunEntry(new_level, new_label,
                            func_dec->params_->MakeFormalTyList(tenv, errormsg),
                            result_ty));
    } else {
      venv->Enter(
          func_dec->name_,
          new env::FunEntry(new_level, new_label,
                            func_dec->params_->MakeFormalTyList(tenv, errormsg),
                            type::VoidTy::Instance()));
    }
  }

  // translate fun one by one
  for (auto func_dec : func_dec_list) {
    // get fun_entry just added
    env::FunEntry *funentry =
        static_cast<env::FunEntry *>(venv->Look(func_dec->name_));
    const auto &access_list = funentry->level_->frame_->formals->GetList();
    const auto &field_list = func_dec->params_->GetList();
    const auto &ty_list =
        func_dec->params_->MakeFormalTyList(tenv, errormsg)->GetList();
    auto it_access = access_list.begin();
    auto it_field = field_list.begin();
    auto it_ty = ty_list.begin();
    venv->BeginScope();
    // add all field entry to venv one by onee
    for (; it_field != field_list.end(); it_field++) {
      // tran frame::access to tr::access
      venv->Enter((*it_field)->name_,
                  new env::VarEntry(
                      new tr::Access(funentry->level_, (*it_access)), *it_ty));
    }

    // generate function fragments and store them
  }
  // fundec doesn't have return exp
  return new tr::ExExp(new tree::ConstExp(0));
}

tr::Exp *VarDec::Translate(env::VEnvPtr venv, env::TEnvPtr tenv,
                           tr::Level *level, temp::Label *label,
                           err::ErrorMsg *errormsg) const {
  tr::ExpAndTy *tr_init = init_->Translate(venv, tenv, level, label, errormsg);

  // decide var type
  type::Ty *var_ty =
      typ_ ? tenv->Look(typ_)->ActualTy() : tr_init->ty_->ActualTy();
  // alloc local for var
  tr::Access *access = tr::Access::AllocLocal(level, escape_);
  venv->Enter(var_, new env::VarEntry(access, var_ty));
  // translate access to exp by staticlink
  tr::Exp *tr_var = new tr::ExExp(
      access->access_->ToExp(tr::StaticLink(access->level_, level)));
  return new tr::NxExp(
      new tree::MoveStm(tr_var->UnEx(), tr_init->exp_->UnEx()));
}

tr::Exp *TypeDec::Translate(env::VEnvPtr venv, env::TEnvPtr tenv,
                            tr::Level *level, temp::Label *label,
                            err::ErrorMsg *errormsg) const {
  const auto &name_and_ty_list = this->types_->GetList();
}

type::Ty *NameTy::Translate(env::TEnvPtr tenv, err::ErrorMsg *errormsg) const {
  type::Ty *ty = tenv->Look(this->name_);
  if (ty) {
    return new type::NameTy(name_, ty);
  } else {
    return type::VoidTy::Instance();
  }
}

type::Ty *RecordTy::Translate(env::TEnvPtr tenv,
                              err::ErrorMsg *errormsg) const {
  /* TODO: Put your lab5 code here */
}

type::Ty *ArrayTy::Translate(env::TEnvPtr tenv, err::ErrorMsg *errormsg) const {
  /* TODO: Put your lab5 code here */
}

} // namespace absyn
