#include "tiger/frame/x64frame.h"

extern frame::RegManager *reg_manager;

namespace frame {

/* TODO: Put your lab5 code here */

// X64RegManager part

X64RegManager frame::X64Frame::regManager = X64RegManager();

temp::TempList* X64RegManager::Registers() {
  static temp::TempList* templist = new temp::TempList();
  // in the order of calling convention
  templist->Append(rax);
  templist->Append(rdi);
  templist->Append(rsi);
  templist->Append(rdx);
  templist->Append(rcx);
  templist->Append(r8);
  templist->Append(r9);
  templist->Append(r10);
  templist->Append(r11);
  templist->Append(rbx);
  templist->Append(rbp);
  templist->Append(r12);
  templist->Append(r13);
  templist->Append(r14);
  templist->Append(r15);
  return templist;
};

temp::TempList* X64RegManager::ArgRegs() {
  static temp::TempList* templist = NULL;

  if (templist) return templist;
  // get reg which can pass args
  templist = new temp::TempList();
  templist->Append(rdi);
  templist->Append(rsi);
  templist->Append(rdx);
  templist->Append(rcx);
  templist->Append(r8);
  templist->Append(r9);
  return templist;
};

temp::TempList* X64RegManager::CallerSaves() {
  static temp::TempList* templist = NULL;

  if (templist) return templist;
  // get caller-save regs
  templist = new temp::TempList();
  templist->Append(rax);
  templist->Append(rdi);
  templist->Append(rsi);
  templist->Append(rdx);
  templist->Append(rcx);
  templist->Append(r8);
  templist->Append(r9);
  templist->Append(r10);
  templist->Append(r11);
  return templist;
};

temp::TempList* X64RegManager::CalleeSaves() {
  static temp::TempList* templist = NULL;

  if (templist) return templist;
  // get callee-save regs
  templist = new temp::TempList();
  templist->Append(rbx);
  templist->Append(rbp);
  templist->Append(r12);
  templist->Append(r13);
  templist->Append(r14);
  templist->Append(r15);
  return templist;
};

// return sink ?
temp::TempList* X64RegManager::ReturnSink() {
  return NULL;
};

int X64RegManager::WordSize() {
  return 8;
};

temp::Temp* X64RegManager::FramePointer() {
  return rbp;
};

temp::Temp* X64RegManager::StackPointer() {
  return rsp;
};

temp::Temp* X64RegManager::ReturnValue() {
  return rax;
};


// x64 Frame part
Access * X64Frame::AllocLocal(bool escape) {
  Access * local = nullptr;
  if(escape) {   // escape local, store in frame
    offset -= reg_manager->WordSize();
    local = new InFrameAccess(offset);
  } else {
    local = new InRegAccess(temp::TempFactory::NewTemp());
  }
  return local;
}

// Access part

tree::Exp* InFrameAccess::ToExp(tree::Exp* framePtr) {
  // auto* 
  return new tree::MemExp(new tree::BinopExp(tree::BinOp::PLUS_OP, framePtr, new tree::ConstExp(this->offset)));
}

tree::Exp* InRegAccess::ToExp(tree::Exp* framePtr)  {
  return new tree::TempExp(this->reg);
}

tree::Exp* externalCall(std::string str, tree::ExpList* args){
  temp::Label * new_label = temp::LabelFactory::NamedLabel(str);
  return new tree::CallExp(new tree::NameExp(new_label), args);
}



} // namespace frame