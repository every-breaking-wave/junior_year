//
// Created by wzl on 2021/10/12.
//

#ifndef TIGER_COMPILER_X64FRAME_H
#define TIGER_COMPILER_X64FRAME_H

#include "tiger/frame/frame.h"

namespace frame {
class X64RegManager : public RegManager {
  /* TODO: Put your lab5 code here */
  // initialize registers
public:
  X64RegManager() : frame::RegManager() {
    rax = temp::TempFactory::NewTemp();
    temp_map_->Enter(rax, new std::string("%rax"));
    rbp = temp::TempFactory::NewTemp();
    temp_map_->Enter(rbp, new std::string("%rbp"));
    rdx = temp::TempFactory::NewTemp();
    temp_map_->Enter(rdx, new std::string("%rdx"));
    rcx = temp::TempFactory::NewTemp();
    temp_map_->Enter(rcx, new std::string("%rcx"));
    rsi = temp::TempFactory::NewTemp();
    temp_map_->Enter(rsi, new std::string("%rsi"));
    rdi = temp::TempFactory::NewTemp();
    temp_map_->Enter(rdi, new std::string("%rdi"));
    rsp = temp::TempFactory::NewTemp();
    temp_map_->Enter(rsp, new std::string("%rsp"));
    rbx = temp::TempFactory::NewTemp();
    temp_map_->Enter(rbx, new std::string("%rbx"));
    r8 = temp::TempFactory::NewTemp();
    temp_map_->Enter(r8, new std::string("%r8"));
    r9 = temp::TempFactory::NewTemp();
    temp_map_->Enter(r9, new std::string("%r9"));
    r10 = temp::TempFactory::NewTemp();
    temp_map_->Enter(r10, new std::string("%r10"));
    r11 = temp::TempFactory::NewTemp();
    temp_map_->Enter(r11, new std::string("%r11"));
    r12 = temp::TempFactory::NewTemp();
    temp_map_->Enter(r12, new std::string("%r12"));
    r13 = temp::TempFactory::NewTemp();
    temp_map_->Enter(r13, new std::string("%r13"));
    r14 = temp::TempFactory::NewTemp();
    temp_map_->Enter(r14, new std::string("%r14"));
    r15 = temp::TempFactory::NewTemp();
    temp_map_->Enter(r15, new std::string("%r15"));
  };

  temp::TempList* Registers();
  temp::TempList* ArgRegs();
  temp::TempList* CallerSaves();
  temp::TempList* CalleeSaves();
  temp::TempList* ReturnSink();
  int WordSize();
  temp::Temp* FramePointer();
  temp::Temp* StackPointer();
  temp::Temp* ReturnValue();

  // temp::Temp* GetNthReg(int i);
  // temp::Temp* GetNthArg(int i);

private:
  temp::Temp *rax, *rbp, *rdi, *rdx, *rcx, *rsi, *rsp, *rbx, *r8, *r9,
      *r10, *r11, *r12, *r13, *r14, *r15;
};

class InFrameAccess : public Access {
public:
  int offset;
  explicit InFrameAccess(int offset) : offset(offset) {}
  tree::Exp* ToExp(tree::Exp* framePtr) override;  // framePtr is useless here but conserve for params consistency
};


class InRegAccess : public Access {
public:
  temp::Temp *reg;

  explicit InRegAccess(temp::Temp *reg) : reg(reg) {}
  tree::Exp* ToExp(tree::Exp* framePtr) override;

};

class X64Frame : public Frame {
public:
  explicit X64Frame(temp::Label *name, std::list<bool> escape_list) : Frame(name) {
      offset = 0;
      for(bool escape : escape_list){
        // alloc a new local depend on escape
        this->formals->PushBack(AllocLocal(escape));
      }
  }

//  void setFormals(const std::list<bool> &escapes) override;

  frame::Access *AllocLocal(bool escape) override;
  static X64RegManager regManager;

};


tree::Exp* externalCall(std::string str, tree::ExpList* args);

} // namespace frame
#endif // TIGER_COMPILER_X64FRAME_H
